#grupo 1 sala t2
#FIlipi Inácio Penha dos santos, # João Pedro carvalho de Jesus, Laura Eduarda Blauth, Giulia Harquihara kroiss

mensagem = input('Mensagem que deseja criptografar: ')
chave = int(input('Chave entre (1, 9): '))
alfabeto = 'abcdefghijklmnopqrstuvwxyz'
def descriptografar():
    codificado = []
    str = ""
    mensagem = input("Escreva a mensagem para descriptografar: ")

def criptografar():
    codificado = []
    str = ""
    mensagem = input("Escreva a mensagem para criptografar: ")
    mensagem = mensagem.lower()
    mensagem = mensagem.lower()
